from django.apps import AppConfig


class Web3AuthConfig(AppConfig):
    name = 'web3auth'
